// Simple API-key check for write operations (create/delete project).
// For a real production app, replace with proper auth (JWT sessions, etc).
module.exports = function requireAdmin(req, res, next) {
  const key = req.header("x-api-key");
  if (!key || key !== process.env.ADMIN_API_KEY) {
    return res.status(401).json({ error: "Unauthorized: missing or invalid API key" });
  }
  next();
};
